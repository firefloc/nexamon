# Enforce canonical spawn after startup; multiple delays avoid late overrides
schedule function spawn_guard:apply 10s append
schedule function spawn_guard:apply 30s append
schedule function spawn_guard:apply 60s append
