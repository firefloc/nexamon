execute in minecraft:overworld run setworldspawn 345 165 680
