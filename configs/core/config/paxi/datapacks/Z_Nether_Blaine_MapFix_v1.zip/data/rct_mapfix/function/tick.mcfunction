# Convert unemployed villagers to Kanto cartographer when near End/Nether cartography tables.
# This enables getting base exploration maps directly in the matching dimension.

# End table checks (3x3 under villager feet)
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:none"}}] at @s if block ~ ~-1 ~ lumymon:end_cartography_table run data merge entity @s {VillagerData:{profession:"lumymon:kanto_cartographer",level:1}}
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:none"}}] at @s if block ~1 ~-1 ~ lumymon:end_cartography_table run data merge entity @s {VillagerData:{profession:"lumymon:kanto_cartographer",level:1}}
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:none"}}] at @s if block ~-1 ~-1 ~ lumymon:end_cartography_table run data merge entity @s {VillagerData:{profession:"lumymon:kanto_cartographer",level:1}}
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:none"}}] at @s if block ~ ~-1 ~1 lumymon:end_cartography_table run data merge entity @s {VillagerData:{profession:"lumymon:kanto_cartographer",level:1}}
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:none"}}] at @s if block ~ ~-1 ~-1 lumymon:end_cartography_table run data merge entity @s {VillagerData:{profession:"lumymon:kanto_cartographer",level:1}}
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:none"}}] at @s if block ~1 ~-1 ~1 lumymon:end_cartography_table run data merge entity @s {VillagerData:{profession:"lumymon:kanto_cartographer",level:1}}
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:none"}}] at @s if block ~1 ~-1 ~-1 lumymon:end_cartography_table run data merge entity @s {VillagerData:{profession:"lumymon:kanto_cartographer",level:1}}
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:none"}}] at @s if block ~-1 ~-1 ~1 lumymon:end_cartography_table run data merge entity @s {VillagerData:{profession:"lumymon:kanto_cartographer",level:1}}
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:none"}}] at @s if block ~-1 ~-1 ~-1 lumymon:end_cartography_table run data merge entity @s {VillagerData:{profession:"lumymon:kanto_cartographer",level:1}}

# Nether table checks (3x3 under villager feet)
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:none"}}] at @s if block ~ ~-1 ~ lumymon:nether_cartography_table run data merge entity @s {VillagerData:{profession:"lumymon:kanto_cartographer",level:1}}
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:none"}}] at @s if block ~1 ~-1 ~ lumymon:nether_cartography_table run data merge entity @s {VillagerData:{profession:"lumymon:kanto_cartographer",level:1}}
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:none"}}] at @s if block ~-1 ~-1 ~ lumymon:nether_cartography_table run data merge entity @s {VillagerData:{profession:"lumymon:kanto_cartographer",level:1}}
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:none"}}] at @s if block ~ ~-1 ~1 lumymon:nether_cartography_table run data merge entity @s {VillagerData:{profession:"lumymon:kanto_cartographer",level:1}}
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:none"}}] at @s if block ~ ~-1 ~-1 lumymon:nether_cartography_table run data merge entity @s {VillagerData:{profession:"lumymon:kanto_cartographer",level:1}}
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:none"}}] at @s if block ~1 ~-1 ~1 lumymon:nether_cartography_table run data merge entity @s {VillagerData:{profession:"lumymon:kanto_cartographer",level:1}}
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:none"}}] at @s if block ~1 ~-1 ~-1 lumymon:nether_cartography_table run data merge entity @s {VillagerData:{profession:"lumymon:kanto_cartographer",level:1}}
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:none"}}] at @s if block ~-1 ~-1 ~1 lumymon:nether_cartography_table run data merge entity @s {VillagerData:{profession:"lumymon:kanto_cartographer",level:1}}
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:none"}}] at @s if block ~-1 ~-1 ~-1 lumymon:nether_cartography_table run data merge entity @s {VillagerData:{profession:"lumymon:kanto_cartographer",level:1}}
